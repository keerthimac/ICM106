package org.example.dao;

public interface SuperDao {
}
