package org.example.util;

public enum BoType {
    CUSTOMER,ITEM
}
