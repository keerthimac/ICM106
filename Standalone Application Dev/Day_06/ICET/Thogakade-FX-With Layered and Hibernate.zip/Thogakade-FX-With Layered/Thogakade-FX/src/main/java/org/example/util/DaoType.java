package org.example.util;

public enum DaoType {
    CUSTOMER,ITEM
}
