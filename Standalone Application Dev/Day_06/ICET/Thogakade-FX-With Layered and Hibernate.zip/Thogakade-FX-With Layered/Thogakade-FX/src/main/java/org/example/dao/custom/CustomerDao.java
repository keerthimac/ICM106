package org.example.dao.custom;

import org.example.dao.CrudDao;
import org.example.entity.CustomerEntity;

public interface CustomerDao extends CrudDao<CustomerEntity> {

}
