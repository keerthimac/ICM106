package org.example.bo;

public interface SuperBo {
}
